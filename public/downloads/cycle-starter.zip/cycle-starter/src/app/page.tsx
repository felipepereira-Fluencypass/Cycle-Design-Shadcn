export default function Home() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">
          Cycle Design System
        </h1>
        <p className="text-muted-foreground text-lg">
          Setup concluido. Pronto para instalar componentes.
        </p>
        <p className="text-sm text-muted-foreground">
          Rode: npx shadcn@latest add button
        </p>
      </div>
    </div>
  )
}
